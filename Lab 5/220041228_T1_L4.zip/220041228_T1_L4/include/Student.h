#ifndef STUDENT_H
#define STUDENT_H
#include<vector>
#include <string>
using namespace std;


class Student
{
    public:
        Student(string studentN, string dept, string prog, string sec, int admY,string adrs, int gp);
        ~Student();

        string GetstudentName() { return studentName; }
        void SetstudentName(string & studentN) { studentName = studentN; }
        string Getdepartment() { return department; }
        void Setdepartment(string & dept) { department = dept; }
        string Getprogram() { return program; }
        void Setprogram(string &prog) { program = prog; }
        string Getsection() { return section; }
        void Setsection(string &sec) { section = sec; }
        int GetadmissionYear() { return admissionYear; }
        void SetadmissionYear(int admY) { admissionYear = admY; }
        string Getaddress() { return address; }
        void Setaddress(string adrs) { address = adrs; }
        int Getgpa() { return gpa; }
        void Setgpa(int gp) { gpa = gp; }
        string GetID(){ return studentID; }
        void GenerateID();


        int calculateGPA(vector<int> & quizzes, int mid, int final_marks,int attendance);

    protected:

    private:
        string studentName;
        string department;
        string program;
        string section;
        int admissionYear;
        string address;
        int gpa;
        int studentId;
};

#endif // STUDENT_H
