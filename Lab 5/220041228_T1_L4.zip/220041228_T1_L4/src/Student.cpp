#include "Student.h"

Student::Student(string studentN, string dept, string prog, string seca, int admY,string adrs, int gp)
{
    //ctor
}

Student::~Student()
{
    //dtor
}

void Student::SetAdmissionYear(int year){
    if(year < 2020 || year > 2023) {
        admissionYear = 2020;
    } else {
        admissionYear = year;
    }
}

void Student::GenerateID() {

}


void Student::calculateGPA(vector<int> & quizzes, int mid, int final_marks,int attendance){
   int totalQ=0;
   for(int quiz:quizzes)
    totalQ+=quiz;

double totalMarks=(totalQuiz/4.0)*0.2 + midterm*0.25 + finalExam*0.45 +attendance*0.1;
 gpa = totalMarks / 100.0 * 4.0;
}



void Student::EditInformationByKeyboard(){

}

void Student::generateInformaiotnRandom()

