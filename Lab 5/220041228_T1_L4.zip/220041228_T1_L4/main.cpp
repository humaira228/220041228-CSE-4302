#include <iostream>
#include "Student.h"
#include <cstdlib>
#include <ctime>
#include <vector>
#include<cstring>

using namespace std;

string generateRandomString(int length) {
    std::string randomString;
    const char alphabet[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    int alphabetSize = sizeof(alphabet) - 1; // Exclude null character

    srand(static_cast<unsigned int>(time(0))); // Seed the random number generator

    for (int i = 0; i < length; ++i) {
        randomString += alphabet[rand() % alphabetSize];
    }

}

void EditInformationByKeyboard(Student &student){
    string studentN, dept, prog,sec,adrs;
    int admY;

    cout<<"Enter Name: ";
    getline(cin,studentN)


    cout << "Enter Department: ";
    getline(cin, dept);
    cout << "Enter Program: ";
    getline(cin, prog);
    cout << "Enter Section: ";
    getline(cin, sec);
    cout << "Enter Admission Year: ";
    cin >> admY;
    cin.ignore();
    cout << "Enter Address: ";
    getline(cin, adrs);

    student.SetName(studentN);
    student.SetDepartment(dept);
    student.SetProgram(prog);
    student.SetSection(sec);
    student.SetAdmissionYear(admY);
    student.SetAddress(adrs);
}



void GenerateInformationRandom(Student &student) {
    string name = generateRandomString(4) + " " + generateRandomString(4);
    string address = generateRandomString(5) + " " + generateRandomString(5) + " " + generateRandomString(5)+" " + generateRandomString(5)+" " + generateRandomString(5);
    int admissionYear = 2020 + rand() % 4;

    student.SetName(name);
    student.SetAddress(address);
    student.SetAdmissionYear(admissionYear);
}

void ShowAllAlphabetically(Student students[], int size){
    sort(students, students + size, [](const Student &a const Student &b){
         return a.GetID()<b.GetID();
});

for (int i=0; i<size; i++){
    cout<<"Name: "<<students[i].GetName()<<" | ID: "<<students[i].GetID()<<" | GPA: "<<fixed<<students[i].GetGPA()<<endl;
}
}


int main(){
    srand(time(0));

    const int numstudents=100;

    student students[numStudents]={
        Student("John Doe","CSE","BSc","A",2022,"Dhaka"),
        Student("Irene Granger","EEE","BSc","B",2022,"Gazipur"),

    };

    for(int i=0; i<2; i++){
        EditInformationByKeyboard(students[i]);
    }
    for(int i=2; i<numStudents; i++)
        GenerateInformationRandom(students[i]);

    ShowAllAlphabetically()



}



}



/*
/// Some example code
#include <string>
#include <cstdlib> // For rand() and srand()
#include <ctime>   // For time()

// Function to generate random string
std::string generateRandomString(int length) {
    std::string randomString;
    const char alphabet[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    int alphabetSize = sizeof(alphabet) - 1; // Exclude null character

    srand(static_cast<unsigned int>(time(0))); // Seed the random number generator

    for (int i = 0; i < length; ++i) {
        randomString += alphabet[rand() % alphabetSize];
    }

    return randomString;
}

int randomInRange(int min, int max) {
    // Ensure min is less than or equal to max
    if (min > max) {
        std::swap(min, max); // Swap if min is greater than max
    }

    return rand() % (max - min + 1) + min;
}

// Function to generate a random double within a given range [min, max]
double randomInRange(double min, double max) {
    // Ensure min is less than or equal to max
    if (min > max) {
        std::swap(min, max); // Swap if min is greater than max
    }

    // Generate a random double between 0 and 1
    double randomFraction = static_cast<double>(rand()) / RAND_MAX;

    // Scale and shift the random value to the desired range
    return min + randomFraction * (max - min);
}
 */





