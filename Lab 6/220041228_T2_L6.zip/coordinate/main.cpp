#include "coordinate.h"
#include <iostream>
#include<cstdlib>
#include<ctime>

using namespace std;

void RandomAsssignment(Coordinate c[],int size){
    srand(static_cast<unsigned>(time(0)));

    for(int i=0; i<size; i++){
        float x=static_cast<float>(rand()%100-50);
        float y=static_cast<float>(rand()%100-50);
        c[i]=Coordinate(x,y);

    }
}

void sortCoordinate(Coordinate coords[], int size){
    for(int i=0; i<size-1; i++){
        for(int j=0; i<size-1; j++){
            if(coords[j]>coords[j+1]){
                Coordinate temp=coords[j];
                coords[j]=coords[j+1];
                coords[j+1]=temp;
            }
        }
    }
}



int main() {
    const int SIZE =10;
    Coordinate coords[SIZE];

    RandomAsssignment(coords, SIZE);
    Coordinate coord[10];




    for (int i = 0; i < SIZE; ++i) {
        coords[i].display();
    }

    sortCoordinate(coords, SIZE);

    for (int i = 0; i < SIZE; ++i) {
        coords[i].display();
    }

    Coordinate c1(1, 1);
    Coordinate c2(-1, -1);
    cout << c1 - c2 << endl;

    return 0;
}
