#include "coordinate.h"

Coordinate::Coordinate() :abscissa(0),ordinate(0){}

Coordinate::Coordinate(float x, float y) :abscissa(x),ordinate(y){}
Coordinate::~Coordinate(){}

void Coordinate::display() const{
    cout<<abscissa<<" , "<<ordinate<<endl;
}

float Coordinate::operator- (const Coordinate & c)const{
    return sqrt(pow(abscissa-c.abscissa,2)+pow(ordinate-c.ordinate,2));
}

float Coordinate:: getDistance()const{
    return sqrt(abscissa*abscissa + ordinate*ordinate);
}

void Coordinate::move_x(float val){
    abscissa+=val;
}

void Coordinate::move_y(float val){
    ordinate+=val;
}

void Coordinate::move(float x_val, float y_val){
    abscissa+=x_val;
    ordinate+=y_val;
}

bool Coordinate::operator>(const Coordinate& c)const{
    return getDistance()>c.getDistance();
}

bool Coordinate::operator<(const Coordinate& c)const{
    return getDistance()<c.getDistance();
}


bool Coordinate::operator>=(const Coordinate& c)const{
    return getDistance()>=c.getDistance();
}

bool Coordinate::operator<=(const Coordinate& c)const{
    return getDistance()<=c.getDistance();
}

bool Coordinate::operator==(const Coordinate& c)const{
    return getDistance()==c.getDistance();
}
bool Coordinate::operator!=(const Coordinate& c)const{
    return !(*this==c);
}

