#include <iostream>

using namespace std;

class Fahrenheit;
class Kelvin;


class Celsius {
private:
    float temperature;

public:
    Celsius();
    Celsius(float temp);
    void assign(float temp);
    void display()const;
    operator Fahrenheit()const;
    operator Kelvin()const;
};

class Fahrenheit {
private:
    float temperature;

public:
    Fahrenheit();
    Fahrenheit(float temp);
    void assign(float temp);
    void display()const;
    operator Celsius()const;
    operator Kelvin()const;
};

class Kelvin{
private:
    float temperature;

public:
    Kelvin();
    Kelvin(float temp);
    void assign(float temp);
    void display()const;
    operator Fahrenheit()const;
    operator Celsius()const;
};


Celsius::Celsius():temperature(0.0){}

Celsius::Celsius(float temp){
assign(temp);
}
void Celsius::assign(float temp){
    if(temp>=-273.15)
        temperature=temp;
}

void Celsius::display()const{
    cout<<temperature<<"Celsius"<<endl;
}

Celsius:: operator Fahrenheit()const{
    return Fahrenheit(temperature*9.0/5.0+32.0);
}

Celsius::operator Kelvin() const{
    return Kelvin(temperature+273.15);
}


Fahrenheit:: Fahrenheit(): temperature(32.0){}
Fahrenheit::Fahrenheit(float temp){
    assign(temp);
}

void Fahrenheit::assign(float temp){
    if(temp>=-459.67){
        temperature=temp;
    }
}




void Fahrenheit::display() const {
    cout<<temperature<<"Fahrenheit"<<endl;
}

Fahrenheit::operator Celsius() const {
    return Celsius((temperature - 32.0) * 5.0 / 9.0);
}

Fahrenheit::operator Kelvin() const {
    return Kelvin((temperature - 32.0) * 5.0 / 9.0 + 273.15);
}



Kelvin::Kelvin() : temperature(273.15) {}

Kelvin::Kelvin(float temp) {
    assign(temp);
}

void Kelvin::assign(float temp) {
    if (temp >= 0.0) {
        temperature = temp;
    }
}

void Kelvin::display() const {
     cout<<temperature<<"Kelvin"<<endl;
}

Kelvin::operator Celsius() const {
    return Celsius(temperature - 273.15);
}

Kelvin::operator Fahrenheit() const {
    return Fahrenheit((temperature - 273.15) * 9.0 / 5.0 + 32.0);
}


